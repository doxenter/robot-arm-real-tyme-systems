#ifndef WAVE_HPP
#define WAVE_HPP

class Wave
{
public:
   Wave();
   bool next(void);

private:
   int rippleNum;
};

#endif // WAVE_HPP

