#ifndef		__DEMO_CREDITS_H__
#define		__DEMO_CREDITS_H__

void init_credits(void);
void update_credits(void);
void draw_credits(void);
void destroy_credits(void);


#endif				/* __DEMO_CREDITS_H__ */
