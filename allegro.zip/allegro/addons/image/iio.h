#ifndef __al_included_allegro5_iio_h
#define __al_included_allegro5_iio_h



#include "allegro5/internal/aintern_image_cfg.h"



typedef struct PalEntry {
   int r, g, b, a;
} PalEntry;


#endif

